package UAS;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.JCheckBox;
import javax.swing.JButton;
import javax.swing.ButtonGroup;
import javax.swing.DefaultComboBoxModel;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.awt.event.ActionEvent;
import javax.swing.JTextArea;
import javax.swing.JScrollPane;

public class MainClasses {

	private JFrame frame;
	private JTextField tfnama;
	private JTextField tfalamat;
	private JTextField tfhp;
	private JTextArea tfhasil;
	int hrgstiker;
	int hrgukuran;
	int chkharga;
	ArrayList<ArrayMain> AM = new ArrayList<ArrayMain>();
	private final ButtonGroup antar = new ButtonGroup();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MainClasses window = new MainClasses();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public MainClasses() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 539, 428);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBounds(10, 35, 273, 86);
		frame.getContentPane().add(panel);
		panel.setLayout(null);
		
		JLabel lbnama = new JLabel("Nama Customers :");
		lbnama.setBounds(10, 11, 89, 15);
		lbnama.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		panel.add(lbnama);
		
		JLabel lbalamat = new JLabel("Alamat :");
		lbalamat.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		lbalamat.setBounds(10, 37, 41, 15);
		panel.add(lbalamat);
		
		JLabel lbhp = new JLabel("No.Telp :");
		lbhp.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		lbhp.setBounds(10, 63, 47, 15);
		panel.add(lbhp);
		
		tfnama = new JTextField();
		tfnama.setColumns(10);
		tfnama.setBounds(104, 8, 159, 20);
		panel.add(tfnama);
		
		tfalamat = new JTextField();
		tfalamat.setColumns(10);
		tfalamat.setBounds(104, 34, 159, 20);
		panel.add(tfalamat);
		
		tfhp = new JTextField();
		tfhp.setColumns(10);
		tfhp.setBounds(104, 60, 159, 20);
		panel.add(tfhp);
		
		JLabel lbhabi = new JLabel("Stiker Habi");
		lbhabi.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 14));
		lbhabi.setBounds(10, 11, 115, 26);
		frame.getContentPane().add(lbhabi);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBounds(10, 130, 273, 99);
		frame.getContentPane().add(panel_1);
		panel_1.setLayout(null);
		
		JLabel lbpesanan = new JLabel("Pesanan");
		lbpesanan.setFont(new Font("Times New Roman", Font.BOLD, 12));
		lbpesanan.setBounds(10, 11, 44, 15);
		panel_1.add(lbpesanan);
		
		JLabel lbstiker = new JLabel("Jenis Sticker :");
		lbstiker.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		lbstiker.setBounds(10, 33, 66, 15);
		panel_1.add(lbstiker);
		
		JLabel lbukuran = new JLabel("Ukuran Kertas :");
		lbukuran.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		lbukuran.setBounds(10, 59, 77, 15);
		panel_1.add(lbukuran);
		
		JComboBox cbstiker = new JComboBox();
		cbstiker.setModel(new DefaultComboBoxModel(new String[] {"", "Stiker Ritrama", "Stiker Oracal", "Stiker Glitter", "Stiker D-Cifix", "Stiker Scotchlite"}));
		cbstiker.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if (cbstiker.getSelectedItem()== "Stiker Ritrama") {
					hrgstiker = 170000;
				} else if (cbstiker.getSelectedItem()== "Stiker Oracal") {
					hrgstiker = 130000;
				} else if (cbstiker.getSelectedItem()== "Stiker Glitter") {
					hrgstiker = 180000;
				} else if (cbstiker.getSelectedItem()== "Stiker D-Cifix") {
					hrgstiker = 200000;
				} else if (cbstiker.getSelectedItem()== "Stiker Scotchlite") {
					hrgstiker = 150000;
				}
			}
		});
		cbstiker.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		cbstiker.setBounds(104, 29, 159, 23);
		panel_1.add(cbstiker);
		
		JComboBox cbukuran = new JComboBox();
		cbukuran.setModel(new DefaultComboBoxModel(new String[] {"", "Vynil A3+", "Fancy A3+", "Papper Matte A4"}));
		cbukuran.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if (cbukuran.getSelectedItem()== "Vynil A3+") {
					hrgukuran = 50000;
				} else if (cbukuran.getSelectedItem()== "Fancy A3+") {
					hrgukuran = 60000;
				} else if (cbukuran.getSelectedItem()== "Papper Matte A4") {
					hrgukuran = 90000;
				}
			}
		});
		cbukuran.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		cbukuran.setBounds(104, 55, 159, 23);
		panel_1.add(cbukuran);
		
		JPanel panel_2 = new JPanel();
		panel_2.setBounds(10, 240, 273, 86);
		frame.getContentPane().add(panel_2);
		panel_2.setLayout(null);
		
		JLabel lbpengantaran = new JLabel("Pengantaran");
		lbpengantaran.setFont(new Font("Times New Roman", Font.BOLD, 12));
		lbpengantaran.setBounds(10, 11, 67, 19);
		panel_2.add(lbpengantaran);
		
		JCheckBox chkbiasa = new JCheckBox("Biasa");
		chkbiasa.setBounds(6, 28, 71, 23);
		panel_2.add(chkbiasa);
		
		JCheckBox chkexpress = new JCheckBox("Express");
		chkexpress.setBounds(6, 54, 82, 23);
		panel_2.add(chkexpress);
		
		JButton btnpesan = new JButton("PESAN");
		btnpesan.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String nm = tfnama.getText();
				String al = tfalamat.getText();
				String hp = tfhp.getText();
				String st = cbstiker.getSelectedItem().toString();
				String uk = cbukuran.getSelectedItem().toString();
				String chkhrg = "";
				
				
				if (chkbiasa.isSelected()) {
					chkhrg = chkbiasa.getText() + "\n";
					chkharga = 30000;
				} else if (chkexpress.isSelected()) {
					chkhrg = chkexpress.getText() + "\n";
					chkharga = 70000;
				}
				
				int chkbon = hrgstiker + hrgukuran + chkharga;
				String bon = String.valueOf(chkbon);
				
				
				ArrayMain ARM = (new ArrayMain(nm,al,hp,st,uk,chkhrg,bon));
				AM.add(ARM);
				String ARM1 = "";
				for ( int i = 0 ; i< AM.size(); i++ ) {
					ARM1 = ("\n nama :" + AM.get(i).tfnama + "\n alamat :" + AM.get(i).tfalamat 
							+ "\n hp :" + AM.get(i).tfhp + "\n Jenis Stiker :" + AM.get(i).cbstiker
							+ "\n Ukuran Stiker :" + AM.get(i).cbukuran + "\n Antar :" + AM.get(i).chkbiasa 
							+ "\n Total Pesanan :" + AM.get(i).bon + "\n");
				}
				tfhasil.setText(ARM1);
				
			}
				
		});
		btnpesan.setBounds(10, 337, 89, 23);
		frame.getContentPane().add(btnpesan);
		// pilih salah satu
		antar.add(chkbiasa);
		antar.add(chkexpress);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(293, 35, 220, 291);
		frame.getContentPane().add(scrollPane);
		
		tfhasil = new JTextArea();
		scrollPane.setViewportView(tfhasil);
		tfhasil.setColumns(10);
	}
}
