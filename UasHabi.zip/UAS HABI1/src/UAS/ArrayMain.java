package UAS;

public class ArrayMain {
	String tfnama, tfalamat, tfhp, cbstiker, cbukuran, chkbiasa, bon;

	
	public ArrayMain(String tfnama, String tfalamat, String tfhp, String cbstiker, String cbukuran, String chkbiasa,
			String bon) {
		super();
		this.tfnama = tfnama;
		this.tfalamat = tfalamat;
		this.tfhp = tfhp;
		this.cbstiker = cbstiker;
		this.cbukuran = cbukuran;
		this.chkbiasa = chkbiasa;
		this.bon = bon;
	}

	
	public String getTfnama() {
		return tfnama;
	}


	public void setTfnama(String tfnama) {
		this.tfnama = tfnama;
	}


	public String getTfalamat() {
		return tfalamat;
	}


	public void setTfalamat(String tfalamat) {
		this.tfalamat = tfalamat;
	}


	public String getTfhp() {
		return tfhp;
	}


	public void setTfhp(String tfhp) {
		this.tfhp = tfhp;
	}


	public String getCbstiker() {
		return cbstiker;
	}


	public void setCbstiker(String cbstiker) {
		this.cbstiker = cbstiker;
	}


	public String getCbukuran() {
		return cbukuran;
	}


	public void setCbukuran(String cbukuran) {
		this.cbukuran = cbukuran;
	}


	public String getChkbiasa() {
		return chkbiasa;
	}


	public void setChkbiasa(String chkbiasa) {
		this.chkbiasa = chkbiasa;
	}


	public String getBon() {
		return bon;
	}


	public void setBon(String bon) {
		this.bon = bon;
	}


	@Override
	public String toString() {
		return "ArrayMain [tfnama=" + tfnama + ", tfalamat=" + tfalamat + ", tfhp=" + tfhp + ", cbstiker=" + cbstiker
				+ ", cbukuran=" + cbukuran + ", chkbiasa=" + chkbiasa + ", bon=" + bon + "]";
	}


	
	
	
}
